import requests
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

API_KEY = "YOUR_GOOGLE_MAPS_API_KEY" # Replace with your actual API key

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/route", methods=["POST"])
def get_route():
    data = request.json
    origin = data.get("origin")
    destination = data.get("destination")
    mode = data.get("mode")

    # URL for Google Maps Directions API
    url = f"https://maps.googleapis.com/maps/api/directions/json?origin={origin}&destination={destination}&mode={mode}&key={API_KEY}"
    
    response = requests.get(url)
    directions = response.json()

    # If the status is OK, send back the directions
    if directions["status"] == "OK":
        return jsonify(directions)
    else:
        return jsonify({"error_message": directions.get("error_message", "Unknown error")})

if __name__ == "__main__":
    app.run(debug=True)
